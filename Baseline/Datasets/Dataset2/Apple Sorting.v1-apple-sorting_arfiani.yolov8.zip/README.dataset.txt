# Apple Sorting > apple sorting_arfiani
https://universe.roboflow.com/arfiani-nur-sayidah-9lizr/apple-sorting-2bfhk

Provided by a Roboflow user
License: CC BY 4.0

## This project was created by Arfiani Nur Sayidah and is for sorting "apples" from "damaged apples."

The classes are "apple" and "damaged_apples"
**Original Class Balance:**
1. apple: 2,152
2. damaged_apple: 708